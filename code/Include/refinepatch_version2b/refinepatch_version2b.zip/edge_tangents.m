function [ET_table,EV_table,ETV_index]=edge_tangents(V,Ne)
[ET_table,EV_table,ETV_index]=edge_tangents_double(double(V),Ne);



